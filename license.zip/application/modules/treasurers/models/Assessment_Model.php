<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Assessment_Model extends CI_Model {

    public $Application_ID;
   
    function __construct()
    {
        parent::__construct();
		$model_list = [
            'treasurers/Fees_Model' => 'MFees',
            'treasurers/Profiles_Model' => 'MProfiles',
		];
        $this->load->model($model_list);
        
        $libray_list = [
            "Logs_library" => 'logs'   
        ];
        $this->load->library($libray_list);
    }

    public function approve_assessment($data,$ID){
        $this->db->set($data);
        $this->db->where('ID', $ID);
        $table = "tbl_assessment";
        $this->db->update($table);

        $module = "Assessment - APPROVED";
        $action = "Update";
        $cyc = $this->assessment_cycle($ID);
        $this->update_logs($module,$table,$action,$cyc->Cycle_ID);
    }

    public function approval_cancel($data,$ID){
        $this->db->set($data);
        $this->db->where('ID', $ID);
        $table = "tbl_assessment";
        $this->db->update($table);

        $module = "Assessment - ASSESSED";
        $action = "Add";
        $this->update_logs($module,$table,$action,$cycle->ID);
    }

    public function assess($data,$ID){
        $cycle = $this->getcycleID($ID);
        $data['Cycle_ID'] = $cycle->ID;
        $table = "tbl_assessment";
        $this->db->insert($table, $data);
        $last_id = $this->db->insert_id();
        
        $module = "Assessment - ASSESSED";
        $action = "Add";
        $this->update_logs($module,$table,$action,$cycle->ID);

        return $last_id;
    }

    public function assessment($ID){
        $cycle = $this->getcycleID($ID);
        $this->db->where('Cycle_ID', $cycle->ID);
        $this->db->order_by('Date_assessed', 'desc');
        $query = $this->db->get('tbl_assessment');
        return $query->first_row();
    }
    
    public function assessment_cycle($Ass_ID){
        $this->db->where('ID', $Ass_ID);
        $query = $this->db->get('tbl_assessment');
        return $query->first_row();
    }

    public function assessment_details($ID){
        $cycle = $this->getcycleID($ID);
        $this->db->select(
            'd.*,'.
            's.Category,'.
            's.Sanitary_fee,'.
            'w.Size,'.
            'w.Waste_fee'
        );
        $this->db->from('tbl_assessment_details d');
        $this->db->join('tbl_fees_sanitary s', 's.ID = d.Category_ID', 'left');
        $this->db->join('tbl_cenro_line c', 'c.Cycle_ID = '.$cycle->ID, 'left');
        $this->db->join('tbl_fees_solid_waste w', 'w.ID = c.Solid_waste_ID', 'left');
        $this->db->where('d.Cycle_ID', $cycle->ID);
        $query = $this->db->get();
        return $query->first_row();
    }

    public function assessment_fees($a_ID){
        $this->db->where('Assessment_ID', $a_ID);
        $query = $this->db->get('tbl_assessment_fees');
        $result = $query->result();  
        
        $tax = [];
        $reg = [];
        $chr = [];

        foreach($result as $r) {
            if($r->Fee_category == 'Business Tax') {
                $tax[$r->Fee_name] = $r->Fee;
            } else if($r->Fee_category == 'Regulatory Fee') {
                $reg[$r->Fee_name] = $r->Fee;
            } else {
                $chr[$r->Fee_name] = $r->Fee;
            }
        }

        $data = new ArrayObject( 
            array(
                'Business Tax' => $tax,
                'Regulatory Fee' => $reg,
                'Other Charge' => $chr
            )
        );
        return $data;
    }

    public function assessment_fees2($a_ID,$ID){
        $cycle = $this->getcycleID($ID);
        $this->db->where('Assessment_ID', $a_ID);
        $query = $this->db->get('tbl_assessment_fees');
        $result = $query->result();

        $collect = $this->db->get_where('tbl_collection',array('Cycle_ID'=>$cycle->ID));    
        
        $tax = [];
        $reg = [];
        $chr = [];

        foreach($result as $r) {
            if($r->Fee_category == 'Business Tax') {
                $tax[$r->Fee_name] = array(
                    "Status" => $r->Fee_status,
                    /* "Fee" => $collect->num_rows() > 0 ? 0 : $r->Fee */
                    "Fee" => $r->Fee
                );
            } else if($r->Fee_category == 'Regulatory Fee') {
                $reg[$r->Fee_name] = array(
                    "Status" => $r->Fee_status,
                    /* "Fee" => $collect->num_rows() > 0 ? 0 : $r->Fee */
                    "Fee" => $r->Fee
                );
            } else {
                $chr[$r->Fee_name]  = array(
                    "Status" => $r->Fee_status,
                    /* "Fee" => $collect->num_rows() > 0 ? 0 : $r->Fee */
                    "Fee" => $r->Fee
                );
            }
        }

        $data = new ArrayObject( 
            array(
                'Business Tax' => $tax,
                'Regulatory Fee' => $reg,
                'Other Charge' => $chr
            )
        );
        return $data;
    }

    public function assessment_fees3($a_ID){
        $this->db->where('Assessment_ID', $a_ID);
        $query = $this->db->get('tbl_assessment_fees');
        $result = $query->result();
        
        $tax = [];
        $reg = [];
        $chr = [];

        foreach($result as $r) {
            if($r->Fee_category == 'Business Tax') {
                $tax[$r->Fee_name] = array(
                    "Status" => $r->Fee_status,
                    "Fee" => $r->Fee
                );
            } else if($r->Fee_category == 'Regulatory Fee') {
                $reg[$r->Fee_name] = array(
                    "Status" => $r->Fee_status,
                    "Fee" => $r->Fee
                );
            } else {
                $chr[$r->Fee_name]  = array(
                    "Status" => $r->Fee_status,
                    "Fee" => $r->Fee
                );
            }
        }

        $data = new ArrayObject( 
            array(
                'Business Tax' => $tax,
                'Regulatory Fee' => $reg,
                'Other Charge' => $chr
            )
        );
        return $data;
    }

    public function assessment_history($ID){
        $this->db->where('ID', $ID);
        $query = $this->db->get('tbl_assessment');
        return $query->first_row();
    }

    public function assessment_information($ID){
        $details = $this->assessment_details($ID);
        $amt = 0; // 12272018 update declared default variable
        if($details == null) {
            return null;
        } else {
            $lines = $this->assessment_lines($ID);
            $fixed = $this->MFees->fixed_fees();
            $profile = $this->MProfiles->get_profile($ID);
            $electrical = $this->getElectrical($ID);

            $others = [];
            if($details->Waste_fee != 0){
                $others['Solid Waste Management Fee'] = $details->Waste_fee;
            }
            if($details->Sanitary_fee != 0){
                $others['Sanitary Fee'] = $details->Sanitary_fee;
            }
            // if($electrical->Rate != 0){
                $others['Electrical Fee'] = $electrical->Rate;
            // }                
            if($details->Flammable != 0){
                $others['Flammable Storage Permit Fee'] = $details->Flammable;
            }
                
            if($details->DSAFee != 0){
                $others['Designated Smoking Area Fee '] = $details->DSAFee;
            }

            $regulatory = [];
            foreach($lines as $key => $line) {
                if (strpos($line->Business_line, 'Storage of Flammable Substance') !== false) { //01-07-2020
                } else if (strpos($line->Business_line, 'Computer') !== false || strpos($line->Business_line, 'Internet') !== false) {
                    $regulatory[$line->Business_line.' - Mayor\'s Permit'] = $line->NoOfUnits * 150;
                } else if(strpos($line->Business_line, 'Cigarette Retailer') !== false) {
                    $regulatory[$line->Business_line.' - Mayor\'s Permit'] = 500;
                } else if(strpos($line->Business_line, 'Videoke') !== false || strpos($line->Business_line, 'Karaoke') !== false) {
                    $regulatory[$line->Business_line.' - Mayor\'s Permit'] = $line->NoOfUnits * 220;
                } else {
                    $regulatory[$line->Business_line.' - Mayor\'s Permit'] = $line->Fee;
                }
            }

            foreach($fixed as $fix) {
                $regulatory[$fix->Category] = $fix->Fee;
            }
            $regulatory['Health Fee'] = ($profile->Total_number_employees * 40);
            
            if($profile->Status == 'NEW'){
                $tax = null;
            } else {
                $tax = [];
                foreach($lines as $key => $line) {
                    if($line->Essential != null || $line->NonEssential != null) {
                        $Gross = ($line->Essential == null) ? $line->NonEssential : $line->Essential;
                        // echo $line->Business_category;
                        if($line->Exempted) {
                            $amt = 0;
                        } else if (strpos(strtoupper($profile->Business_name), 'NORTHERN NEGROS ELECTRIC') !== false) {
                            $amt = $Gross * 0.01 * 0.825;
                        } else if (strpos(strtoupper($line->Business_line), 'MEDICAL CLINIC') !== false) {
                            $amt = 0;
                        } else if (strpos(strtoupper($line->Business_line), 'GASOLINE') !== false) {
                            $amt = 0;
                        } else if (strpos(strtoupper($line->Business_line), 'CRUDE OIL') !== false) {
                            $amt = 0;
                        } else if (strpos(strtoupper($line->Business_line), 'GAS RETAILER') !== false) {
                            $amt = 0;
                        } else if (strpos(strtoupper($line->Business_line), 'COOPERATIVE') !== false) {
                            $amt = 0;
                        } else if (strpos(strtoupper($profile->Business_name), 'COOPERATIVE') !== false) {
                            $amt = 0;
                        } else if (trim(strtoupper($line->Business_category)) == 'MANUFACTURER' || 
                                trim(strtoupper($line->Business_category)) == 'PRODUCER') {
                            if($Gross < 50000) {
                                $amt = 0;
                            } else if($Gross >= 6500000) {
                                $excess = $Gross - 6500000;
                                $amt = $excess * 0.01 * 0.44 + 40218.75;
                            } else {
                                $this->db->where('Gross_from <=', $Gross);
                                $this->db->where('Gross_to >=', $Gross);
                                $query = $this->db->get('tbl_tax_manufacturer')->first_row();
                                $amt = $query->Tax;
                            }
                        } else if(trim(strtoupper($line->Business_category)) == 'DEALER' || 
                                trim(strtoupper($line->Business_category)) == 'WHOLESALER' || 
                                trim(strtoupper($line->Business_category)) == 'OTHERS') {
                            if((strpos(strtoupper($line->Business_line), 'BEER') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'LIQUOR') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'CIGARETTE') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'SOFTDRINKS') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'SOFT DRINKS') !== false)) {
                                    if($Gross < 50000) {
                                        $amt = 500;
                                    } else if($Gross == 50000) {
                                        $amt = 1089;
                                    } else if($Gross >= 2000000) {
                                        $excess = $Gross - 2000000;
                                        $amt = $excess * 0.01 * 0.44 + 16500;
                                    } else {
                                        $this->db->where('Gross_from <=', $Gross);
                                        $this->db->where('Gross_to >=', $Gross);
                                        $query = $this->db->get('tbl_tax_dealer')->first_row();
                                        $amt = $query->Tax;
                                    }
                            } else {
                                if($Gross < 50000) {
                                    $amt = 0;
                                } else if($Gross >= 2000000) {
                                    $excess = $Gross - 2000000;
                                    $amt = $excess * 0.01 * 0.44 + 16500;
                                } else {
                                    $this->db->where('Gross_from <=', $Gross);
                                    $this->db->where('Gross_to >=', $Gross);
                                    $query = $this->db->get('tbl_tax_dealer')->first_row();
                                    $amt = $query->Tax;
                                }
                            }
                        } else if(trim(strtoupper($line->Business_category)) == 'RETAILER') {
                            if($Gross <= 50000) {
                                if((strpos(strtoupper($line->Business_line), 'BEER') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'LIQUOR') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'SOFTDRINKS') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'SOFT DRINKS') !== false) ||
                                (strpos(strtoupper($line->Business_line), 'CIGARETTE') !== false)) {
                                    $amt = 300;
                                } else {
                                    $amt = 0;
                                }
                            } else if($Gross > 400000) {
                                $excess = $Gross - 400000;
                                $amt = $excess * 0.0165 + 13200;
                            } else {
                                $amt = $Gross * 0.033;
                            }
                        } else if(trim(strtoupper($line->Business_category)) == 'FINANCIAL') {
                            if($Gross < 50000) {
                                $amt = 0;
                            } else {
                                $amt = ($Gross * 0.01) * 0.825;
                            }
                        } else if(trim(strtoupper($line->Business_category)) == 'SERVICE') {
                            if($Gross < 50000) {
								if(strpos(strtoupper($line->Business_line), 'VIDEOKE') !== false) {
									$amt = 220;
								} else {
									$amt = 0;
								}
                            } else if($Gross >= 2000000) {
                                $excess = $Gross - 2000000;
                                $amt = $excess * 0.01 * 0.44 + 18975;
                            } else {
                                $this->db->where('Gross_from <=', $Gross);
                                $this->db->where('Gross_to >=', $Gross);
                                $query = $this->db->get('tbl_tax_service')->first_row();
                                $amt = $query->Tax;
                            }
                        } else if(trim(strtoupper($line->Business_category)) == 'AMUSEMENT') {
                            if(strpos(strtoupper($line->Business_line), 'BILLARD') !== false) {
                                if($Gross <= 50000) {
                                    $amt = 330;
                                } else if($Gross >= 2000000) {
                                    $excess = $Gross - 2000000;
                                    $amt = $excess * 0.01 * 0.44 + 18975;
                                } else {
                                    $this->db->where('Gross_from <=', $Gross);
                                    $this->db->where('Gross_to >=', $Gross);
                                    $query = $this->db->get('tbl_tax_service')->first_row();
                                    $amt = $query->Tax;
                                }
                            } else {
                                if($Gross < 50000) {
                                    $amt = 0;
                                } else {
                                    $amt = $Gross * 0.1;
                                }
                            }
                        } else if(trim(strtoupper($line->Business_category)) == 'FOOD ESTABLISHMENT') {
                            if($Gross < 50000) {
                                $amt = 0;
                            } else if($Gross == 50000)  {
                                $amt = 1237.50;
                            } else {
                                $amt = ((($Gross - 50000) / 1000) * 27.50) + 1237.50;
                            }
                        }
                        $rate = ($line->Essential == null) ? $amt : $amt / 2;
                        if($rate != 0) {
                            $tax[$line->Business_line] = $rate;
                        }
                    }
                }
            }
            
            $data = new ArrayObject( 
                array(
                    'Business Tax' => $tax,
                    'Regulatory Fee' => $regulatory,
                    'Other Charge' => $others
                )
            );
            return $data;
            // echo json_encode($data);
        }
    }
    
    // public function assessment_lines($ID){
    //     $cycle = $this->getcycleID($ID);
    //     $this->db->select(
    //         'a.*,'.
    //         's.Asset_size,'.
    //         's.Characteristics,'.
    //         'f.Fee'
    //     );
    //     $this->db->from('tbl_application_business_line a');
    //     $this->db->join('tbl_assessment_asset s', 's.Asset_from <= a.Capitalization AND s.Asset_to >= a.Capitalization', 'left');
    //     $this->db->join('tbl_fees_mayors_permit f', 'f.Category = a.Business_category AND f.Characteristics = s.Characteristics', 'left');
    //     $this->db->where('a.Cycle_ID', $cycle->ID);
    //     $this->db->order_by('a.ID', 'asc');
    //     $query = $this->db->get();
    //     return $query->result();
    // }
    
    public function assessment_lines($ID){
        $cycle = $this->getcycleID($ID);
        $this->db->where('Cycle_ID', $cycle->ID);
        $this->db->where('Retirement', 0);
        $this->db->order_by('ID', 'asc');
        $query = $this->db->get('tbl_application_business_line');
        $result = $query->result();

        foreach($result as $key => $r) {
            if($r->Assessment_asset_ID == null) {
                $r->Asset_size = null;
                $r->Characteristics = null;
                $r->Fee = null;
            } else {
                // $this->db->select(
                //     's.Asset_size,'.
                //     's.Characteristics,'.
                //     'f.Fee'
                // );
                // $this->db->from('tbl_application_business_line a');
                // $this->db->join('tbl_assessment_asset s', 's.Asset_from <= a.Capitalization AND s.Asset_to >= a.Capitalization', 'left');
                // $this->db->join('tbl_fees_mayors_permit f', 'f.Category = a.Business_category AND f.Characteristics = s.Characteristics', 'left');
                // $this->db->where('a.ID', $r->ID);
                // $result2 = $this->db->get()->first_row();
				$this->db->where('ID', $r->Assessment_asset_ID);
				$asset = $this->db->get('tbl_assessment_asset')->first_row();
				
				$this->db->where('Category', $r->Business_category);
				$this->db->where('Characteristics', $asset->Characteristics);
				$mayors = $this->db->get('tbl_fees_mayors_permit')->first_row();

                $r->Asset_size = $asset->Asset_size;
                $r->Characteristics = $asset->Characteristics;
                $r->Fee = @$mayors->Fee;
            }
        }

        return $result;
    }

    public function delete($ID){
        $this->db->delete("tbl_assessment_fees", array('Assessment_ID' => $ID));
        $this->db->delete("tbl_billing_fees", array('Assessment_ID' => $ID));
        $this->db->delete("tbl_assessment", array('ID' => $ID));
        
        $module = "Assessment - OVERRIDE";
        $table = "tbl_assessment, tbl_assessment_fees, tbl_billing_fees";
        $action = "Delete";
        $cyc = $this->assessment_cycle($ID);
        $this->update_logs($module,$table,$action,$cyc->Cycle_ID);
    }

    public function details($data,$ID){
        $cycle = $this->getcycleID($ID);
        $data['Cycle_ID'] = $cycle->ID;
        $table = "tbl_assessment_details";
        $this->db->insert($table, $data);

        $module = "Assessment - DETAILS";
        $action = "Add";
        $this->update_logs($module,$table,$action,$cycle->ID);
    }
    
    public function fees($array,$ID){
        $table = "tbl_assessment_fees";
        $Fee_names = $array['Fee_name'];
        $Fee_category = $array['Fee_category'];
        $Fee_stat = $array['Fee_stat'];
        $Fee = $array['Fee'];
        $data = [];
        foreach($Fee_names as $key => $Fee_name) {
            array_push($data, array(
                    "Assessment_ID" => $ID,
                    "Fee_name" => $Fee_name,
                    "Fee_category" => $Fee_category[$key],
                    "Fee_status" => ($Fee_stat[$key] == '') ? null : $Fee_stat[$key],
                    "Fee" => $Fee[$key]
                )
            );
        }
        $this->db->insert_batch($table, $data);
        
        $module = "Assessment - ASSESSED";
        $action = "Add";
        $cyc = $this->assessment_cycle($ID);
        $this->update_logs($module,$table,$action,$cyc->Cycle_ID);
    }

    // private function getAsset($Cap){
    //     $this->db->where('Asset_from <=', $Cap);
    //     $this->db->where('Asset_to >=', $Cap);
    //     $query = $this->db->get('tbl_assessment_asset');
    //     return $query->first_row();
    // }

    private function getcycleDate($ID){
        $this->db->select('tbl_cycle.Cycle_date');
        $this->db->order_by('ID', 'desc');
        $query = $this->db->get_where('tbl_cycle',array('Application_ID'=>$ID))->first_row();        
        return $query;
    }

    private function getcycleID($ID){
        $cycle = $this->getcycleDate($ID);   
        $this->db->select('ID');
        $this->db->from('tbl_cycle');
        $this->db->where('Cycle_date', $cycle->Cycle_date);
        $this->db->where('Application_ID', $ID);
        $this->db->order_by('ID', 'desc');
        $query = $this->db->get()->first_row();    
        return $query;
    }

    public function getElectrical($ID){
        $cycle = $this->getcycleID($ID);
        $this->db->select_sum('e.Rate');
        $this->db->from('tbl_city_engineer c');
        $this->db->join('tbl_city_engineer_line e', 'e.City_engineer_ID = c.ID', 'left');
        $this->db->where('c.Cycle_ID', $cycle->ID);
        $query = $this->db->get();
        return $query->first_row();
    }

    // private function getFee($Cat,$Char){
    //     $this->db->where('Category', $Cat);
    //     $this->db->where('Characteristics', $Char);
    //     $query = $this->db->get('tbl_fees_mayors_permit');
    //     return $query->first_row();
    // }

    // public function lines($array,$ID){
    //     $cycle = $this->getcycleID($ID);
    //     $table = "tbl_assessment_business_line";
    //     $Business_line_IDs = $array['Business_line_ID'];
    //     $Capital = $array['Capital'];
    //     $Gross = $array['Gross'];
    //     $data = [];
    //     foreach($Business_line_IDs as $key => $Business_line_ID) {
    //         array_push($data, array(
    //                 "Cycle_ID" => $cycle->ID,
    //                 "Business_line_ID" => $Business_line_ID,
    //                 "Capital" => $Capital[$key],
    //                 "Gross" => $Gross[$key]
    //             )
    //         );
    //     }
    //     $this->db->insert_batch($table, $data);
    // }
    
    public function history_details($ID){
        $this->db->select(
            'd.*,'.
            's.Category,'.
            's.Sanitary_fee,'.
            'w.Size,'.
            'w.Waste_fee'
        );
        $this->db->from('tbl_assessment_details d');
        $this->db->join('tbl_fees_sanitary s', 's.ID = d.Category_ID', 'left');
        $this->db->join('tbl_cenro_line c', 'c.Cycle_ID = '.$ID, 'left');
        $this->db->join('tbl_fees_solid_waste w', 'w.ID = c.Solid_waste_ID', 'left');
        $this->db->where('d.Cycle_ID', $ID);
        $query = $this->db->get();
        return $query->first_row();
    }
    
    public function history_lines($ID){
        $this->db->where('Cycle_ID', $ID);
        $this->db->order_by('ID', 'asc');
        $query = $this->db->get('tbl_application_business_line');
        $result = $query->result();

        foreach($result as $key => $r) {
            if($r->Assessment_asset_ID == null) {
                $r->Asset_size = null;
                $r->Characteristics = null;
                $r->Fee = null;
            } else {
				$this->db->where('ID', $r->Assessment_asset_ID);
				$asset = $this->db->get('tbl_assessment_asset')->first_row();
				
				$this->db->where('Category', $r->Business_category);
				$this->db->where('Characteristics', $asset->Characteristics);
				$mayors = $this->db->get('tbl_fees_mayors_permit')->first_row();

                $r->Asset_size = $asset->Asset_size;
                $r->Characteristics = $asset->Characteristics;
                $r->Fee = @$mayors->Fee;
            }
        }

        return $result;
    }
    
    public function update_assessment($data,$ID,$Ass_ID){
        $table = "tbl_assessment";
        $this->db->where('ID', $Ass_ID);
        $this->db->update($table, $data);

        $module = "Assessment - ASSESSED";
        $action = "Update";
        $cyc = $this->assessment_cycle($ID);
        $this->update_logs($module,$table,$action,$cyc->Cycle_ID);
    }
    
    public function update_details($data,$AppID,$ID){
        $table = "tbl_assessment_details";
        $cycle = $this->getcycleID($AppID);
        $data['Cycle_ID'] = $cycle->ID;
        $this->db->where('ID', $ID);
        $this->db->update($table, $data);
        
        $module = "Assessment - DETAILS";
        $action = "Update";
        $this->update_logs($module,$table,$action,$cycle->ID);
    }
    
    public function update_fees($array,$ID){
        $table = "tbl_assessment_fees";
        $Fee_names = $array['Fee_name'];
        $Fee = $array['Fee'];
        $data = [];
        foreach($Fee_names as $key => $Fee_name) {
            array_push($data, array(
                    "Fee_name" => $Fee_name,
                    "Fee" => $Fee[$key]
                )
            );
        }
        $this->db->where('Assessment_ID', $ID);
        $this->db->update_batch($table, $data, 'Fee_name');

        $module = "Assessment - ASSESSED";
        $action = "Update";
        $cyc = $this->assessment_cycle($ID);
        $this->update_logs($module,$table,$action,$cyc->Cycle_ID);
    }

    public function update_lines($array,$App_ID){
        $cycle = $this->getcycleID($App_ID);
        $table = "tbl_application_business_line";
        $IDs = $array['Business_line_ID'];
        $Capitalization = $array['Capitalization'];
        $Essential = $array['Essential'];
        $NonEssential = $array['NonEssential'];
        $Assessment_asset_ID = $array['Assessment_asset_ID'];
        $Exempted = $array['Exempted'];
        $data = [];
        foreach($IDs as $key => $ID) {
            array_push($data, array(
                    "ID" => $ID,
                    "Capitalization" => $Capitalization[$key],
                    "Essential" => ($Essential[$key] == '') ? null : $Essential[$key],
                    "NonEssential" => ($NonEssential[$key] == '') ? null : $NonEssential[$key],
                    "Assessment_asset_ID" => $Assessment_asset_ID[$key],
                    "Exempted" => $Exempted[$key],
                )
            );
        }
        $this->db->where('Cycle_ID', $cycle->ID);
        $this->db->update_batch($table, $data, 'ID');
        
        $module = "Business Lines";
        $action = "Update";
        $this->update_logs($module,$table,$action,$cycle->ID);
    }

    public function update_ready($ID){
        $this->db->select('Cycle_ID');
        $this->db->from('tbl_assessment');
        $this->db->where('ID', $ID);
        $query = $this->db->get()->first_row();

        $this->db->set('Status', "Done");
        $this->db->where('Cycle_ID', $query->Cycle_ID);
        $this->db->update('tbl_ready_to_assess');
        
        $module = "Ready to Assess - DONE";
        $table = "tbl_ready_to_assess";
        $action = "Update";
        $this->update_logs($module,$table,$action,$query->Cycle_ID);
    }

    public function assessment_collection_status(){
        $status = [
            'ready' => false,
            'assess' => false,
            'payed' => false, 
        ];
        $this->db->from('tbl_ready_to_assess r');
        $this->db->join('tbl_cycle c','c.ID=r.Cycle_ID','left');
        $this->db->join('tbl_application_form a','a.ID=c.Application_ID','left');
        $this->db->where('a.ID',$this->Application_ID);
        $ready_to_assess_query = $this->db->get()->first_row();

        if($ready_to_assess_query!=null){
            $status['ready'] = true;
        }

        $this->db->from('tbl_assessment as');
        $this->db->join('tbl_cycle c','c.ID=as.Cycle_ID','left');
        $this->db->join('tbl_application_form a','a.ID=c.Application_ID','left');
        $this->db->order_by('as.ID','desc');
        $this->db->where('as.Status','Approved');
        $this->db->where('a.ID',$this->Application_ID);
        $assess_query = $this->db->get()->first_row();
        
        if($assess_query!=null){
            $status['assess'] = true;
        }

        $this->db->from('tbl_collection co');
        $this->db->join('tbl_cycle c','c.ID=co.Cycle_ID','left');
        $this->db->join('tbl_application_form a','a.ID=c.Application_ID','left');
        $this->db->order_by('co.ID','desc');
        $this->db->where('a.ID',$this->Application_ID);
        $payed_query = $this->db->get()->first_row();

        if($payed_query!=null){
            $status['payed'] = true;
        }

        return  $status;
    }

    public function update_logs($module,$table,$action,$ID) {
        $this->logs->User_ID = $_SESSION['User_details']->ID;
        $this->logs->Last_name = $_SESSION['User_details']->Last_name;
        $this->logs->Module = $module;
        $this->logs->Table = $table;
        $this->logs->Action = $action;
        $this->logs->Application_ID = $this->MProfiles->get_App_ID($ID);
        $this->logs->record();
    }
}